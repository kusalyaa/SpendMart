//
//  SpendMartApp.swift
//  SpendMart
//
//  Created by  			Kusalya 023 on 2025-08-17.
//

import SwiftUI

@main
struct SpendMartApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
