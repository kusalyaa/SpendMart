import Foundation

struct ScannedExpense {
    var merchant: String
    var amount: Double
    var date: Date?
    var rawText: String
}
